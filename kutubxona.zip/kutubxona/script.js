let books = [];

async function loadBooks() {
  const response = await fetch("kitoblar.json");
  books = await response.json();
  displayBooks(books);
}

function displayBooks(data) {
  const results = document.getElementById("results");
  results.innerHTML = "";

  data.forEach(book => {
    const div = document.createElement("div");
    div.className = "book";
    div.innerHTML = `
      <h3>${book.nomi}</h3>
      <p><strong>Muallif:</strong> ${book.muallif}</p>
      <p><strong>Tur:</strong> ${book.turi}</p>
      <p><strong>Elektron versiya:</strong> ${book.link ? `<a href="${book.link}" target="_blank">O‘qish/Yuklash</a>` : "Yo‘q"}</p>
      <p><strong>Kutubxonada:</strong> ${book.kutubxonada ? "Bor" : "Yo‘q"}</p>
    `;
    results.appendChild(div);
  });
}

function searchBooks() {
  const query = document.getElementById("search").value.toLowerCase();
  const filtered = books.filter(book =>
    book.nomi.toLowerCase().includes(query) ||
    book.muallif.toLowerCase().includes(query) ||
    book.turi.toLowerCase().includes(query)
  );
  displayBooks(filtered);
}

document.addEventListener("DOMContentLoaded", loadBooks);
